package com.kikoy.sistempakar;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class login extends AppCompatActivity {

    LinearLayout info;
    EditText username, password;
    Button btnMasuk,btnRegis;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        info = findViewById(R.id.profile);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        btnMasuk = (Button)findViewById(R.id.loginbtn);
        btnRegis = (Button)findViewById(R.id.register);

        btnMasuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameKey = username.getText().toString();
                String passwordKey = password.getText().toString();

                if (usernameKey.equals("admin")&& passwordKey.equals("admin")){
                    Toast.makeText(getApplicationContext(),"Anda Berhasil Masuk", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(login.this, dashboard.class);
                    startActivity(intent);
                    finish();
                }else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(login.this);
                    builder.setMessage("Username Atau Password Yang Anda Masukan Salah !!!").setNegativeButton("Retry",null).create().show();
                }
            }
        });
        btnRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(login.this, register.class);
                startActivity(intent);
                finish();
            }
        });

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(login.this, profile.class);
                startActivity(intent);
                finish();
            }
        });

    }
}